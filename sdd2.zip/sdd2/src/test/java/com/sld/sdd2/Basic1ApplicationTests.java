package com.sld.sdd2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Basic1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
